console.log("Hello World");
//Var sirve para declarar una variable
var a = 1;
var b = 2;
var R = a + b;
console.log("Resultado sum: " + R);

var c = 4;
var d = 2;
var F = c * d;
console.log("Resultado mul: " + F);

var G = Math. sqrt(1244);
console.log("Resultado raiz: " + G);

var raiz2=Math.trunc(G)
console.log("El resultado de la Raíz aproximada es: " + raiz2);

var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}